package storestock.Panier.repository

import org.springframework.stereotype.Repository
import storestock.Panier.domain.Cart
import storestock.user.repository.CartRepository
import java.util.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
@Repository
class CartInMemoryRepository : CartRepository {

    private val map = mutableMapOf<Pair<String, UUID>, Cart>()

    override fun addToCart(cart: Cart): Result<Cart> {
        val stock = getStockForItemId(cart.ItemId)
        if (stock == null || stock<1) {
            return Result.failure(Exception("Cannot add this Item"))
        }

        val emailExists = doesEmailExist(cart.email)
        if (!emailExists) {
            return Result.failure(Exception("Email does not exist"))
        }

        val previous = map.putIfAbsent(Pair(cart.email,cart.ItemId), cart)
        return if (previous == null) {
            Result.success(cart)
        } else {
            Result.failure(Exception("Cart already exit"))
        }
    }

    override fun listCarts(): List<Cart> {
        return map.values.toList()
    }

    override fun updateCart(cart: Cart): Result<Cart> {
        TODO("Not yet implemented")
    }

    override fun deleteItemCart(email: String): Cart? {
        TODO("Not yet implemented")
    }

    override fun ValidateCart(email: String): Cart? {
        TODO("Not yet implemented")
    }

/*
    override fun create(user: User): Result<User> {
        val previous = map.putIfAbsent(user.email, user)
        return if (previous == null) {
            Result.success(user)
        } else {
            Result.failure(Exception("User already exit"))
        }
    }

    override fun list(age: Int?) = if (age == null) {
        map.values.toList()
    } else {
        map.values.filter { it.age == age }
    }

    override fun get(email: String) = map[email]

    override fun update(user: User): Result<User> {
        val updated = map.replace(user.email, user)
        return if (updated == null) {
            Result.failure(Exception("User doesn't exit"))
        } else {
            Result.success(user)
        }
    }

    override fun delete(email: String) = map.remove(email)
    */

}


fun doesEmailExist(email: String): Boolean {
    val url = URL("http://localhost:8080/api/users/$email")
    val connection = url.openConnection() as HttpURLConnection
    connection.requestMethod = "GET"

    try {
        val responseCode = connection.responseCode
        if (responseCode == HttpURLConnection.HTTP_OK) {
            return true
        } else if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
            return false
        } else {
            return false
        }
    } finally {
        connection.disconnect()
    }
}

fun getStockForItemId(itemId: UUID): Int? {
    val url = URL("http://localhost:8081/api/articles/$itemId")
    val connection = url.openConnection() as HttpURLConnection
    connection.requestMethod = "GET"

    try {
        val responseCode = connection.responseCode
        if (responseCode == HttpURLConnection.HTTP_OK) {
            val reader = BufferedReader(InputStreamReader(connection.inputStream))
            val responseContent = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                responseContent.append(line)
            }
            reader.close()

            // Analysez la réponse pour extraire la valeur "Stock" si elle est au format JSON par exemple
            val jsonResponse = responseContent.toString()
            val stockValue = parseStockFromJson(jsonResponse)

            return stockValue
        } else {
            return null
        }
    } finally {
        connection.disconnect()
    }
}

fun parseStockFromJson(jsonResponse: String): Int? {
    /*
    val gson = Gson()
    val jsonObject = gson.fromJson(jsonResponse, JsonObject::class.java)
    return jsonObject?.get("stock")?.asInt
    */

    // Ici, nous supposons simplement que la réponse est un nombre entier
    try {
        return jsonResponse.toInt()
    } catch (e: NumberFormatException) {
        // Gérez l'erreur si la réponse n'est pas un nombre valide
        return null
    }
}