package storestock.Panier

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class PanierApplication

fun main(args: Array<String>) {
	runApplication<PanierApplication>(*args)
}
